package com.quiz.db;

public class Question {
	
	 public   String question;
	 public   String[] options;
	 public  int correctOption; // 0-based index

	    public Question(String question, String[] options, int correctOption) {
	        this.question = question;
	        this.options = options;
	        this.correctOption = correctOption;
	    }
	}


