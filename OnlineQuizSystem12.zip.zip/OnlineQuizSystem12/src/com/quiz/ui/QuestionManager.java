package com.quiz.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import com.quiz.db.Question;

public class QuestionManager extends JFrame {
    private ArrayList<Question> questionList = new ArrayList<>();
    private DefaultListModel<String> listModel;

    public QuestionManager() {
        setTitle("Manage Questions");
        setSize(700, 500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel title = new JLabel("Question Manager", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBounds(200, 20, 300, 30);
        add(title);

        listModel = new DefaultListModel<>();
        JList<String> questionJList = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(questionJList);
        scrollPane.setBounds(50, 70, 600, 250);
        add(scrollPane);

        JButton addBtn = new JButton("Add Question");
        addBtn.setBounds(100, 350, 150, 40);
        add(addBtn);

        JButton deleteBtn = new JButton("Delete Question");
        deleteBtn.setBounds(280, 350, 150, 40);
        add(deleteBtn);

        JButton backBtn = new JButton("Back");
        backBtn.setBounds(460, 350, 150, 40);
        add(backBtn);

        addBtn.addActionListener(e -> addNewQuestion());
        deleteBtn.addActionListener(e -> deleteSelectedQuestion(questionJList));
        backBtn.addActionListener(e -> {
            dispose();
            new AdminDashboard().setVisible(true);
        });
    }

    private void addNewQuestion() {
        JTextField qField = new JTextField();
        JTextField aField = new JTextField();
        JTextField bField = new JTextField();
        JTextField cField = new JTextField();
        JTextField dField = new JTextField();
        JTextField ansField = new JTextField();

        Object[] fields = {
            "Question:", qField,
            "Option A:", aField,
            "Option B:", bField,
            "Option C:", cField,
            "Option D:", dField,
            "Correct Option (0=A,1=B,2=C,3=D):", ansField
        };

        int option = JOptionPane.showConfirmDialog(null, fields, "Add Question", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            Question q = new Question(
                    qField.getText(),
                    new String[]{aField.getText(), bField.getText(), cField.getText(), dField.getText()},
                    Integer.parseInt(ansField.getText())
            );
            questionList.add(q);
            listModel.addElement(qField.getText());
        }
    }

    private void deleteSelectedQuestion(JList<String> questionJList) {
        int index = questionJList.getSelectedIndex();
        if (index >= 0) {
            questionList.remove(index);
            listModel.remove(index);
        } else {
            JOptionPane.showMessageDialog(this, "Select a question to delete!");
        }
    }

    public static void main(String[] args) {
        new QuestionManager().setVisible(true);
    }
}

