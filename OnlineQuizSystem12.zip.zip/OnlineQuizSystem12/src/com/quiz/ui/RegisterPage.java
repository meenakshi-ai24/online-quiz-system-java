package com.quiz.ui;
import javax.swing.*;

public class RegisterPage {
    public static void main(String[] args) {
JFrame frame = new JFrame("Register Page");
frame.setSize(400, 300);
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
frame.setLayout(null);

// Username
JLabel userLabel = new JLabel("Username:");
userLabel.setBounds(50, 50, 100, 30);
frame.add(userLabel);

JTextField userText = new JTextField();
userText.setBounds(150, 50, 150, 30);
frame.add(userText);

// Password
JLabel passLabel = new JLabel("Password:");
passLabel.setBounds(50, 100, 100, 30);
frame.add(passLabel);

JPasswordField passText = new JPasswordField();
passText.setBounds(150, 100, 150, 30);
frame.add(passText);

//Email
JLabel emailLabel = new JLabel("Email:");
emailLabel.setBounds(50, 140, 100, 30);
frame.add(emailLabel);

JTextField emailText = new JTextField();
emailText.setBounds(150, 140, 150, 30);
frame.add(emailText);

// Register button
JButton registerButton = new JButton("Register");
registerButton.setBounds(150, 200, 100, 30);
frame.add(registerButton);
registerButton.addActionListener(e -> {
    String username = userText.getText();
    String password = new String(passText.getPassword());

    try {
        // DB connection call
        java.sql.Connection con = com.quiz.db.DBConnection.getConnection();
        String query = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
        java.sql.PreparedStatement pst = con.prepareStatement(query);
        pst.setString(1, username);
        pst.setString(2, password);
        pst.setString(3, emailText.getText());

        int rows = pst.executeUpdate();
        if (rows > 0) {
            JOptionPane.showMessageDialog(frame, "Registration Successful!");
        } else {
            JOptionPane.showMessageDialog(frame, "Registration Failed!");
        }

        pst.close();
        con.close();

    } catch (Exception ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage());
    }
});
//Login Button (RegisterPage me)
JButton loginButton = new JButton("Login");
loginButton.setBounds(270, 200, 100, 30);
frame.add(loginButton);

loginButton.addActionListener(e -> {
 frame.dispose(); // current window close
 LoginPage.main(null); // Login page open
});

frame.setVisible(true);
}
}