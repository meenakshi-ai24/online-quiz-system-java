package com.quiz.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class InstructionsPage extends JFrame {

    public InstructionsPage(String username) {
        setTitle("Quiz Instructions");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Background color
        getContentPane().setBackground(new Color(240, 248, 255));

        JLabel title = new JLabel("Welcome " + username + "!");
        title.setFont(new Font("Poppins", Font.BOLD, 26));
        title.setBounds(220, 30, 400, 40);
        add(title);

        JTextArea instructions = new JTextArea();
        instructions.setText(
                "📘 Quiz Instructions:\n\n"
                + "1️⃣ You will get 20 questions divided into 3 modules.\n"
                + "2️⃣ Each question has 4 options (a, b, c, d).\n"
                + "3️⃣ You will have 10 seconds to answer each question.\n"
                + "4️⃣ Each correct answer gives you +1 mark.\n"
                + "5️⃣ No negative marking.\n"
                + "6️⃣ Once you move to the next question, you cannot go back.\n"
                + "7️⃣ Your final result will be displayed at the end.\n\n"
                + "📢 Click 'Start Quiz' to begin your test. Good luck!"
        );
        instructions.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        instructions.setEditable(false);
        instructions.setLineWrap(true);
        instructions.setWrapStyleWord(true);
        instructions.setBackground(new Color(245, 250, 255));
        instructions.setBounds(70, 90, 550, 270);
        instructions.setBorder(BorderFactory.createLineBorder(new Color(180, 180, 255), 2));
        add(instructions);

        JButton startBtn = new JButton("Start Quiz");
        startBtn.setFont(new Font("Poppins", Font.BOLD, 18));
        startBtn.setBackground(new Color(70, 130, 180));
        startBtn.setForeground(Color.WHITE);
        startBtn.setFocusPainted(false);
        startBtn.setBounds(250, 380, 180, 40);
        startBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        add(startBtn);

        startBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open Quiz Page
                new QuizPage(username).setVisible(true);
                dispose();
            }
        });
    }

    public static void main(String[] args) {
        new InstructionsPage("Student").setVisible(true);
    }
}
