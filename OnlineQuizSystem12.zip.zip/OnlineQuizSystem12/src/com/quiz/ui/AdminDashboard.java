package com.quiz.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminDashboard extends JFrame {
    public AdminDashboard() {
        setTitle("Admin Dashboard");
        setSize(600, 400);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel heading = new JLabel("Welcome Admin!", SwingConstants.CENTER);
        heading.setFont(new Font("Arial", Font.BOLD, 24));
        heading.setBounds(150, 30, 300, 40);
        add(heading);

        JButton manageQuestionsBtn = new JButton("Manage Questions");
        manageQuestionsBtn.setBounds(200, 100, 200, 40);
        add(manageQuestionsBtn);

        JButton viewUsersBtn = new JButton("View Users");
        viewUsersBtn.setBounds(200, 160, 200, 40);
        add(viewUsersBtn);

        JButton viewResultsBtn = new JButton("View Results");
        viewResultsBtn.setBounds(200, 220, 200, 40);
        add(viewResultsBtn);

        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setBounds(200, 280, 200, 40);
        add(logoutBtn);

        manageQuestionsBtn.addActionListener(e -> {
            dispose();
            new QuestionManager().setVisible(true);
        });

        logoutBtn.addActionListener(e -> {
            dispose();
            new AdminLogin().setVisible(true);
        });
    }

    public static void main(String[] args) {
        new AdminDashboard().setVisible(true);
    }
}
