package com.quiz.ui;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;

public class LoginPage {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Login Page");
        frame.setSize(400, 300); // width, height
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 50, 100, 30);  // x, y, width, height
        frame.add(userLabel);

        JTextField userText = new JTextField();
        userText.setBounds(150, 50, 150, 30);
        frame.add(userText);
        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(50, 100, 100, 30);
        frame.add(passLabel);

        JPasswordField passText = new JPasswordField();
        passText.setBounds(150, 100, 150, 30);
        frame.add(passText);
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(150, 160, 100, 30);
        frame.add(loginButton);
        
            		loginButton.addActionListener(e -> {
            		    String username = userText.getText();
            		    String password = new String(passText.getPassword());

            		    try {
            		        Connection con = com.quiz.db.DBConnection.getConnection();
            		        String sql = "SELECT * FROM users WHERE username=? AND password=?";
            		        PreparedStatement pst = con.prepareStatement(sql);
            		        pst.setString(1, username);
            		        pst.setString(2, password);

            		        ResultSet rs = pst.executeQuery();

            		        if (rs.next()) {
            		            JOptionPane.showMessageDialog(frame, "Login Successful!");
            		            frame.dispose();
            		            QuizPage.main(null);
            		        } else {
            		            JOptionPane.showMessageDialog(frame, "Invalid Username or Password");
            		        }

            		        con.close();
            		    } catch (Exception ex) {
            		        ex.printStackTrace();
            		        JOptionPane.showMessageDialog(frame, "Database Error!");
            		    }
            		});
                    JButton registerButton = new JButton("Register");
                    registerButton.setBounds(150, 200, 100, 30);
                    frame.add(registerButton);

                    registerButton.addActionListener(e -> {
                        frame.dispose();            // Login window band
                        RegisterPage.main(null);    // RegisterPage khol do
                    });


        frame.setVisible(true);
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

