package com.quiz.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;

public class LeaderboardPage extends JFrame {

    static ArrayList<Player> players = new ArrayList<>();

    public LeaderboardPage() {
        setTitle("Leaderboard");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(250, 250, 255));
        setLayout(null);

        JLabel title = new JLabel("🏆 Leaderboard");
        title.setFont(new Font("Poppins", Font.BOLD, 26));
        title.setBounds(190, 20, 300, 40);
        add(title);

        // Sort players by score descending
        players.sort(Comparator.comparingInt(Player::getScore).reversed());

        // Table setup
        String[] columns = {"Rank", "Name", "Score"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        int rank = 1;
        for (Player p : players) {
            if (rank > 5) break;
            model.addRow(new Object[]{rank, p.getName(), p.getScore()});
            rank++;
        }

        JTable table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        table.setRowHeight(30);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(100, 80, 400, 200);
        add(scrollPane);

        JButton back = new JButton("Exit");
        back.setFont(new Font("Poppins", Font.BOLD, 16));
        back.setBounds(240, 300, 100, 35);
        back.setBackground(new Color(220, 53, 69));
        back.setForeground(Color.WHITE);
        add(back);

        back.addActionListener(e -> System.exit(0));
    }

    // Store player info
    public static void addPlayer(String name, int score) {
        players.add(new Player(name, score));
    }

    public static class Player {
        private String name;
        private int score;

        public Player(String name, int score) {
            this.name = name;
            this.score = score;
        }

        public String getName() { return name; }
        public int getScore() { return score; }
    }

    public static void main(String[] args) {
        addPlayer("Meenakshi", 18);
        addPlayer("Parul", 16);
        addPlayer("Anisha", 14);
        addPlayer("Chagan", 12);
        addPlayer("Kuldeep", 10);
        new LeaderboardPage().setVisible(true);
    }
}

