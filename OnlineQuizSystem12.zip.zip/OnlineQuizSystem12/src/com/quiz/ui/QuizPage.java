package com.quiz.ui;

import javax.swing.*;
import com.quiz.db.Question;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class QuizPage {

    public static void main(String[] args) {
        // FRAME
        JFrame frame = new JFrame("Smart Quiz System");
        frame.setSize(800, 600);
        frame.setLayout(null);
        frame.getContentPane().setBackground(new Color(240, 248, 255)); // light blue background
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        // WELCOME LABEL
        JLabel welcomeLabel = new JLabel("Welcome to the Online Quiz!", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("SansSerif", Font.BOLD, 26));
        welcomeLabel.setBounds(150, 150, 500, 40);
        welcomeLabel.setForeground(new Color(25, 25, 112));
        frame.add(welcomeLabel);

        // START BUTTON
        JButton startButton = new JButton("Start Quiz");
        startButton.setFont(new Font("SansSerif", Font.BOLD, 18));
        startButton.setBackground(new Color(173, 216, 230));
        startButton.setBounds(320, 250, 150, 50);
        startButton.setFocusPainted(false);
        frame.add(startButton);

        // ACTION FOR START
        startButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                welcomeLabel.setVisible(false);
                startButton.setVisible(false);

                // Question Label
                JLabel questionLabel = new JLabel("", SwingConstants.LEFT);
                questionLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
                questionLabel.setBounds(80, 60, 650, 60);
                frame.add(questionLabel);

                // Timer Label (Styled Box)
                JLabel timerLabel = new JLabel("Time: 10", SwingConstants.CENTER);
                timerLabel.setOpaque(true);
                timerLabel.setBackground(new Color(255, 160, 122));
                timerLabel.setForeground(Color.WHITE);
                timerLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
                timerLabel.setBounds(670, 20, 100, 40);
                timerLabel.setBorder(BorderFactory.createLineBorder(Color.RED, 2));
                frame.add(timerLabel);

                // Option Buttons
                JRadioButton[] optionButtons = new JRadioButton[4];
                ButtonGroup group = new ButtonGroup();
                char optChar = 'A';

                for (int i = 0; i < 4; i++) {
                    optionButtons[i] = new JRadioButton();
                    optionButtons[i].setFont(new Font("SansSerif", Font.PLAIN, 16));
                    optionButtons[i].setBounds(100, 150 + (i * 50), 600, 40);
                    optionButtons[i].setBackground(new Color(240, 248, 255));
                    optionButtons[i].setFocusPainted(false);
                    group.add(optionButtons[i]);
                    frame.add(optionButtons[i]);
                }

                // Next Button
                JButton nextButton = new JButton("Next ➜");
                nextButton.setFont(new Font("SansSerif", Font.BOLD, 16));
                nextButton.setBounds(330, 420, 130, 45);
                nextButton.setBackground(new Color(173, 216, 230));
                nextButton.setFocusPainted(false);
                frame.add(nextButton);

                // --------------------- QUESTION BANK ---------------------
                ArrayList<Question> allQuestions = new ArrayList<>();

                allQuestions.add(new Question("What is an algorithm?",
                        new String[]{"A computer hardware device", "A step-by-step procedure to solve a problem", "A programming language", "A web browser"}, 1));

                allQuestions.add(new Question("What does time complexity measure?",
                        new String[]{"Memory taken", "The speed of an algorithm", "Number of programmers required", "Cost of an algorithm"}, 1));

                allQuestions.add(new Question("Which notation represents upper bound of an algorithm’s complexity?",
                        new String[]{"Big-O", "Theta", "Omega", "Delta"}, 0));

                allQuestions.add(new Question("Binary Search works only on:",
                        new String[]{"Linked lists", "Unsorted data", "Sorted data", "Images"}, 2));

                allQuestions.add(new Question("Time complexity of Binary Search is:",
                        new String[]{"O(n)", "O(log n)", "O(n^2)", "O(1)"}, 1));

                allQuestions.add(new Question("Which method divides the problem into smaller subproblems?",
                        new String[]{"Dynamic Programming", "Greedy", "Divide & Conquer", "Brute Force"}, 2));

                allQuestions.add(new Question("Merge Sort belongs to which category?",
                        new String[]{"Greedy", "Divide & Conquer", "Brute Force", "Backtracking"}, 1));

                allQuestions.add(new Question("Worst-case time complexity of Merge Sort:",
                        new String[]{"O(log n)", "O(n log n)", "O(n^2)", "O(1)"}, 1));

                allQuestions.add(new Question("Quick Sort uses which type of element selection?",
                        new String[]{"Middle element", "Pivot element", "Largest element", "Smallest element"}, 1));

                allQuestions.add(new Question("Best-case time complexity of Quick Sort:",
                        new String[]{"O(n^2)", "O(n log n)", "O(1)", "O(n^3)"}, 1));

                allQuestions.add(new Question("What major step does Merge Sort include?",
                        new String[]{"Pivot selection", "Searching", "Merging sorted arrays", "Hashing"}, 2));

                allQuestions.add(new Question("Divide & Conquer contains which steps?",
                        new String[]{"Backup, Restore, Update", "Divide, Conquer, Combine", "Start, Stop", "Push, Pop"}, 1));

                allQuestions.add(new Question("Strassen’s algorithm is used for:",
                        new String[]{"String searching", "Matrix multiplication", "File sorting", "CPU scheduling"}, 1));

                allQuestions.add(new Question("Complexity of standard matrix multiplication:",
                        new String[]{"O(n^3)", "O(n^2)", "O(n log n)", "O(log n)"}, 0));

                allQuestions.add(new Question("Which algorithm requires extra memory?",
                        new String[]{"Merge Sort", "Quick Sort", "Binary Search", "BFS"}, 0));

                allQuestions.add(new Question("Binary Search technique is:",
                        new String[]{"Recursive only", "Iterative only", "Both recursive and iterative", "None"}, 2));

                allQuestions.add(new Question("Quick Sort usually performs well because:",
                        new String[]{"It uses less stack memory", "Good average-case performance", "It does not require pivot", "It is hardware dependent"}, 1));

                allQuestions.add(new Question("Which notation represents lower bound?",
                        new String[]{"Big-O", "Big-Theta", "Big-Omega", "Sigma"}, 2));

                // --------------------- QUIZ LOGIC ---------------------
                final int[] currentQuestion = {0};
                final int[] score = {0};
                final int timePerQuestion = 10;
                final int[] timeLeft = {timePerQuestion};

                Timer timer = new Timer(1000, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        timeLeft[0]--;
                        timerLabel.setText("Time: " + timeLeft[0]);
                        if (timeLeft[0] <= 0) {
                            ((Timer) e.getSource()).stop();
                            nextButton.doClick();
                        }
                    }
                });

                // SHOW FIRST QUESTION
                Question q = allQuestions.get(currentQuestion[0]);
                questionLabel.setText((currentQuestion[0] + 1) + ") " + q.question);
                for (int i = 0; i < 4; i++) {
                    optionButtons[i].setText((char) ('A' + i) + ") " + q.options[i]);
                    optionButtons[i].setSelected(false);
                }
                timer.start();

                // NEXT BUTTON ACTION
                nextButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent ev) {
                        Question currentQ = allQuestions.get(currentQuestion[0]);
                        for (int i = 0; i < 4; i++) {
                            if (optionButtons[i].isSelected() && i == currentQ.correctOption) {
                                score[0]++;
                            }
                        }

                        currentQuestion[0]++;
                        if (currentQuestion[0] < allQuestions.size()) {
                            Question nextQ = allQuestions.get(currentQuestion[0]);
                            questionLabel.setText((currentQuestion[0] + 1) + ") " + nextQ.question);
                            for (int i = 0; i < 4; i++) {
                                optionButtons[i].setText((char) ('A' + i) + ") " + nextQ.options[i]);
                                optionButtons[i].setSelected(false);
                            }
                            timeLeft[0] = timePerQuestion;
                            timer.restart();
                        } else {
                            timer.stop();
                            int totalQuestions = allQuestions.size();
                            int correctAnswers = score[0];
                            new ResultPage(score[0], totalQuestions, correctAnswers).setVisible(true);
                            frame.dispose();
                        }
                    }
                });

                frame.repaint();
            }
        });

        frame.setVisible(true);
    }
}
