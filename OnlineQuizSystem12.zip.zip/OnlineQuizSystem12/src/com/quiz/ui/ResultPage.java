package com.quiz.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ResultPage extends JFrame {

    public ResultPage(int score, int totalQuestions, int correctAnswers) {
        setTitle("Quiz Result");
        setSize(500, 400);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Background color
        getContentPane().setBackground(new Color(240, 248, 255));

        JLabel titleLabel = new JLabel("🎉 Quiz Completed!", SwingConstants.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 24));
        titleLabel.setBounds(100, 40, 300, 40);
        add(titleLabel);

        JLabel scoreLabel = new JLabel("Your Score: " + score + " / " + totalQuestions, SwingConstants.CENTER);
        scoreLabel.setFont(new Font("SansSerif", Font.PLAIN, 18));
        scoreLabel.setBounds(100, 100, 300, 30);
        add(scoreLabel);

        JLabel correctLabel = new JLabel("Correct Answers: " + correctAnswers, SwingConstants.CENTER);
        correctLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
        correctLabel.setBounds(100, 140, 300, 30);
        add(correctLabel);

        int percentage = (int) (((double) score / totalQuestions) * 100);
        JLabel percentageLabel = new JLabel("Percentage: " + percentage + "%", SwingConstants.CENTER);
        percentageLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
        percentageLabel.setBounds(100, 180, 300, 30);
        add(percentageLabel);

        JLabel remarkLabel = new JLabel("", SwingConstants.CENTER);
        remarkLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
        remarkLabel.setBounds(100, 230, 300, 30);
        add(remarkLabel);

        if (percentage >= 80) {
            remarkLabel.setText("Excellent Work! 🏆");
            remarkLabel.setForeground(new Color(0, 128, 0));
        } else if (percentage >= 50) {
            remarkLabel.setText("Good Job! 👍");
            remarkLabel.setForeground(new Color(255, 140, 0));
        } else {
            remarkLabel.setText("Keep Practicing! 💪");
            remarkLabel.setForeground(Color.RED);
        }

        // Buttons
        JButton retryButton = new JButton("Try Again");
        retryButton.setBounds(120, 290, 100, 35);
        retryButton.setBackground(new Color(173, 216, 230));
        retryButton.setFocusPainted(false);
        add(retryButton);

        JButton exitButton = new JButton("Exit");
        exitButton.setBounds(270, 290, 100, 35);
        exitButton.setBackground(new Color(255, 182, 193));
        exitButton.setFocusPainted(false);
        add(exitButton);

        // Retry Action
        retryButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                QuizPage.main(null); // restart quiz
            }
        });

        // Exit Action
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Thank you for playing! 😊");
 
                System.exit(0);
            }
        });

        setVisible(true);
    }

    // For testing separately
    public static void main(String[] args) {
        new ResultPage(8, 10, 8);
    }
}
