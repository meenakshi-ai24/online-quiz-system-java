package com.quiz.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminLogin extends JFrame {
    public AdminLogin() {
        setTitle("Admin Login");
        setSize(400, 300);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel title = new JLabel("Admin Login", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 22));
        title.setBounds(100, 20, 200, 30);
        add(title);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(60, 80, 100, 30);
        add(userLabel);

        JTextField usernameField = new JTextField();
        usernameField.setBounds(160, 80, 160, 30);
        add(usernameField);

        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(60, 130, 100, 30);
        add(passLabel);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(160, 130, 160, 30);
        add(passwordField);

        JButton loginBtn = new JButton("Login");
        loginBtn.setBounds(140, 190, 120, 40);
        add(loginBtn);

        loginBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String user = usernameField.getText();
                String pass = new String(passwordField.getPassword());

                if (user.equals("admin") && pass.equals("admin123")) {
                    JOptionPane.showMessageDialog(null, "Login Successful!");
                    dispose();
                    new AdminDashboard().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Credentials!");
                }
            }
        });
    }

    public static void main(String[] args) {
        new AdminLogin().setVisible(true);
    }
}
